
- https://docs.phalcon.io/3.4/en/webserver-setup#nginx