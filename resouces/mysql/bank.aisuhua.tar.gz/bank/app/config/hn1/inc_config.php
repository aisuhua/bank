<?php
$GLOBALS['db']['host'] = '172.17.0.2';
$GLOBALS['db']['port'] = 3306;
$GLOBALS['db']['username'] = 'root';
$GLOBALS['db']['password'] = 'suhua123';
$GLOBALS['db']['dbname'] = 'bank';
$GLOBALS['db']['charset'] = 'utf8mb4';