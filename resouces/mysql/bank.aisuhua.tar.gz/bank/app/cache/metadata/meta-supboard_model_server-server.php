<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'server_group_id',
    2 => 'ip',
    3 => 'port',
    4 => 'username',
    5 => 'password',
    6 => 'agent_port',
    7 => 'agent_root',
    8 => 'update_time',
    9 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'server_group_id',
    1 => 'ip',
    2 => 'port',
    3 => 'username',
    4 => 'password',
    5 => 'agent_port',
    6 => 'agent_root',
    7 => 'update_time',
    8 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'server_group_id',
    2 => 'ip',
    3 => 'port',
    4 => 'username',
    5 => 'password',
    6 => 'agent_port',
    7 => 'agent_root',
    8 => 'update_time',
    9 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'server_group_id' => 0,
    'ip' => 2,
    'port' => 0,
    'username' => 2,
    'password' => 2,
    'agent_port' => 0,
    'agent_root' => 2,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'server_group_id' => true,
    'port' => true,
    'agent_port' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'server_group_id' => 1,
    'ip' => 2,
    'port' => 1,
    'username' => 2,
    'password' => 2,
    'agent_port' => 1,
    'agent_root' => 2,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'ip' => '',
    'username' => '',
    'password' => '',
    'agent_root' => '',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 