<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'customer_code',
    2 => 'acc_number',
    3 => 'open_org',
    4 => 'balance',
    5 => 'update_time',
    6 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'customer_code',
    1 => 'acc_number',
    2 => 'open_org',
    3 => 'balance',
    4 => 'update_time',
    5 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'customer_code',
    2 => 'acc_number',
    3 => 'open_org',
    4 => 'balance',
    5 => 'update_time',
    6 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'customer_code' => 2,
    'acc_number' => 2,
    'open_org' => 2,
    'balance' => 3,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'balance' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'customer_code' => 2,
    'acc_number' => 2,
    'open_org' => 2,
    'balance' => 32,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'customer_code' => '',
    'acc_number' => '',
    'open_org' => '',
    'balance' => '0.00',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 