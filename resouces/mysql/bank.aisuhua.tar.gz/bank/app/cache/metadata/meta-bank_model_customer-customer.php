<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'customer_code',
    2 => 'customer_name',
    3 => 'profile',
    4 => 'update_time',
    5 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'customer_code',
    1 => 'customer_name',
    2 => 'profile',
    3 => 'update_time',
    4 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'customer_code',
    2 => 'customer_name',
    3 => 'profile',
    4 => 'update_time',
    5 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'customer_code' => 2,
    'customer_name' => 2,
    'profile' => 2,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'customer_code' => 2,
    'customer_name' => 2,
    'profile' => 2,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'customer_code' => '',
    'customer_name' => '',
    'profile' => '',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 