<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'acc_number',
    2 => 'trans_time',
    3 => 'amount',
    4 => 'opp_acc_number',
    5 => 'opp_customer_name',
    6 => 'update_time',
    7 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'acc_number',
    1 => 'trans_time',
    2 => 'amount',
    3 => 'opp_acc_number',
    4 => 'opp_customer_name',
    5 => 'update_time',
    6 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'acc_number',
    2 => 'trans_time',
    3 => 'amount',
    4 => 'opp_acc_number',
    5 => 'opp_customer_name',
    6 => 'update_time',
    7 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'acc_number' => 2,
    'trans_time' => 14,
    'amount' => 3,
    'opp_acc_number' => 2,
    'opp_customer_name' => 2,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'trans_time' => true,
    'amount' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'acc_number' => 2,
    'trans_time' => 1,
    'amount' => 32,
    'opp_acc_number' => 2,
    'opp_customer_name' => 2,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'acc_number' => '',
    'trans_time' => '0',
    'amount' => '0.00',
    'opp_acc_number' => '',
    'opp_customer_name' => '',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 