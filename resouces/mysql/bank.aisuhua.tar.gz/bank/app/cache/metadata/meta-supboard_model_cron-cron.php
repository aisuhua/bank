<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'server_id',
    2 => 'user',
    3 => 'command',
    4 => 'time',
    5 => 'status',
    6 => 'description',
    7 => 'last_time',
    8 => 'update_time',
    9 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'server_id',
    1 => 'user',
    2 => 'command',
    3 => 'time',
    4 => 'status',
    5 => 'description',
    6 => 'last_time',
    7 => 'update_time',
    8 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'server_id',
    2 => 'user',
    3 => 'command',
    4 => 'time',
    5 => 'status',
    6 => 'description',
    7 => 'last_time',
    8 => 'update_time',
    9 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'server_id' => 0,
    'user' => 2,
    'command' => 2,
    'time' => 2,
    'status' => 0,
    'description' => 2,
    'last_time' => 0,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'server_id' => true,
    'status' => true,
    'last_time' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'server_id' => 1,
    'user' => 2,
    'command' => 2,
    'time' => 2,
    'status' => 1,
    'description' => 2,
    'last_time' => 1,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'server_id' => '0',
    'user' => '',
    'command' => '',
    'time' => '',
    'status' => '0',
    'description' => '',
    'last_time' => '0',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 