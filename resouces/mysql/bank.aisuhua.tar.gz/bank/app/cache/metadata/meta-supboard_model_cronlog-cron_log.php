<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'cron_id',
    2 => 'server_id',
    3 => 'user',
    4 => 'program',
    5 => 'command',
    6 => 'status',
    7 => 'start_time',
    8 => 'end_time',
    9 => 'update_time',
    10 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'cron_id',
    1 => 'server_id',
    2 => 'user',
    3 => 'program',
    4 => 'command',
    5 => 'status',
    6 => 'start_time',
    7 => 'end_time',
    8 => 'update_time',
    9 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'cron_id',
    2 => 'server_id',
    3 => 'user',
    4 => 'program',
    5 => 'command',
    6 => 'status',
    7 => 'start_time',
    8 => 'end_time',
    9 => 'update_time',
    10 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'cron_id' => 0,
    'server_id' => 0,
    'user' => 2,
    'program' => 2,
    'command' => 2,
    'status' => 0,
    'start_time' => 0,
    'end_time' => 0,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'cron_id' => true,
    'server_id' => true,
    'status' => true,
    'start_time' => true,
    'end_time' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'cron_id' => 1,
    'server_id' => 1,
    'user' => 2,
    'program' => 2,
    'command' => 2,
    'status' => 1,
    'start_time' => 1,
    'end_time' => 1,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'cron_id' => '0',
    'server_id' => '0',
    'user' => '',
    'program' => '',
    'command' => '',
    'status' => '0',
    'start_time' => '0',
    'end_time' => '0',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 