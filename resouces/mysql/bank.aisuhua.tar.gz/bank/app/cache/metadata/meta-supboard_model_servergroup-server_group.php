<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'description',
    3 => 'sort',
    4 => 'update_time',
    5 => 'create_time',
    6 => 'suhua',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'name',
    1 => 'description',
    2 => 'sort',
    3 => 'update_time',
    4 => 'create_time',
    5 => 'suhua',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'description',
    3 => 'sort',
    4 => 'update_time',
    5 => 'create_time',
    6 => 'suhua',
  ),
  4 => 
  array (
    'id' => 0,
    'name' => 2,
    'description' => 2,
    'sort' => 0,
    'update_time' => 0,
    'create_time' => 0,
    'suhua' => 2,
  ),
  5 => 
  array (
    'id' => true,
    'sort' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'name' => 2,
    'description' => 2,
    'sort' => 1,
    'update_time' => 1,
    'create_time' => 1,
    'suhua' => 2,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'name' => '',
    'description' => '',
    'sort' => '0',
    'update_time' => '0',
    'create_time' => '0',
    'suhua' => '',
  ),
  13 => 
  array (
  ),
); 