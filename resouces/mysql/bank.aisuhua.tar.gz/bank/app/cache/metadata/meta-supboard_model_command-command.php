<?php return array (
  0 => 
  array (
    0 => 'id',
    1 => 'server_id',
    2 => 'program',
    3 => 'user',
    4 => 'command',
    5 => 'status',
    6 => 'start_time',
    7 => 'end_time',
    8 => 'update_time',
    9 => 'create_time',
  ),
  1 => 
  array (
    0 => 'id',
  ),
  2 => 
  array (
    0 => 'server_id',
    1 => 'program',
    2 => 'user',
    3 => 'command',
    4 => 'status',
    5 => 'start_time',
    6 => 'end_time',
    7 => 'update_time',
    8 => 'create_time',
  ),
  3 => 
  array (
    0 => 'id',
    1 => 'server_id',
    2 => 'program',
    3 => 'user',
    4 => 'command',
    5 => 'status',
    6 => 'start_time',
    7 => 'end_time',
    8 => 'update_time',
    9 => 'create_time',
  ),
  4 => 
  array (
    'id' => 0,
    'server_id' => 0,
    'program' => 2,
    'user' => 2,
    'command' => 2,
    'status' => 0,
    'start_time' => 0,
    'end_time' => 0,
    'update_time' => 0,
    'create_time' => 0,
  ),
  5 => 
  array (
    'id' => true,
    'server_id' => true,
    'status' => true,
    'start_time' => true,
    'end_time' => true,
    'update_time' => true,
    'create_time' => true,
  ),
  8 => 'id',
  9 => 
  array (
    'id' => 1,
    'server_id' => 1,
    'program' => 2,
    'user' => 2,
    'command' => 2,
    'status' => 1,
    'start_time' => 1,
    'end_time' => 1,
    'update_time' => 1,
    'create_time' => 1,
  ),
  10 => 
  array (
  ),
  11 => 
  array (
  ),
  12 => 
  array (
    'server_id' => '0',
    'program' => '',
    'user' => '',
    'command' => '',
    'status' => '0',
    'start_time' => '0',
    'end_time' => '0',
    'update_time' => '0',
    'create_time' => '0',
  ),
  13 => 
  array (
  ),
); 