

<div id="pjax-container">
    <?= $this->getContent() ?>
</div>

<div style="height: 20px;"></div>