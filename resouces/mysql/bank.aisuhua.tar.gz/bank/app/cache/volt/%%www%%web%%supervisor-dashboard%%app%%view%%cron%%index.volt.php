<?= $this->getContent() ?>
<?= $this->flashSession->output() ?>
<ol class="breadcrumb">
    <li class="active"><?= $server->serverGroup->name ?></li>
    <li class="active"><?= $server->ip ?>:<?= $server->port ?></li>
</ol>

<?php $index_class = ''; ?>
<?php $create_class = ''; ?>
<?php $ini_class = ''; ?>
<?php $cron_class = ''; ?>
<?php $cron_create_class = ''; ?>
<?php $cron_log_class = ''; ?>
<?php $command_class = ''; ?>
<?php $command_history_class = ''; ?>

<?php if ($this->dispatcher->getControllerName() == 'process-manager') { ?>
    <?php $index_class = 'active'; ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'process') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit' || $this->dispatcher->getActionName() == 'createIni' || $this->dispatcher->getActionName() == 'editIni') { ?>
        <?php $create_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'ini') { ?>
        <?php $ini_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit') { ?>
        <?php $cron_create_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron-log') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_log_class = 'active'; ?>
    <?php } ?>

<?php } elseif ($this->dispatcher->getControllerName() == 'command') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $command_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'history') { ?>
        <?php $command_history_class = 'active'; ?>
    <?php } ?>
<?php } ?>

<ul id="" class="nav nav-tabs my-tabs1" role="tablist" style="margin-bottom: 20px;">
    <li role="presentation" class="<?= $index_class ?>"><a href="/process?server_id=<?= $server->id ?>&ip=<?= $server->ip ?>&port=<?= $server->port ?>">进程列表</a></li>
    <li role="presentation" class="<?= $create_class ?>"><a href="/process/create?server_id=<?= $server->id ?>">添加/修改进程</a></li>
    <li role="presentation" class="<?= $ini_class ?>"><a href="/process/ini?server_id=<?= $server->id ?>">进程配置</a></li>
    <li role="presentation" class="<?= $cron_class ?>"><a href="/cron?server_id=<?= $server->id ?>">定时任务列表</a></li>
    <li role="presentation" class="<?= $cron_create_class ?>"><a href="/cron/create?server_id=<?= $server->id ?>">添加/修改定时任务</a></li>
    <li role="presentation" class="<?= $cron_log_class ?>"><a href="/cron-log?server_id=<?= $server->id ?>">定时任务日志</a></li>
    <li role="presentation" class="<?= $command_class ?>"><a href="/command?server_id=<?= $server->id ?>">执行命令</a></li>
    <li role="presentation" class="<?= $command_history_class ?>"><a href="/command/history?server_id=<?= $server->id ?>">命令执行历史</a></li>
    
</ul>

<script>
function reloadConfig() {
    $.get('/process-manager/reloadConfig?server_id=<?= $server->id ?>');
}

$(function() {
    var ini_editor = document.getElementById('ini');

    if (ini_editor) {
        var editor = CodeMirror.fromTextArea(document.getElementById('ini'));
        editor.setSize('100%', '100%');

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            editor.refresh();
        });
    }
});
</script>

<?php if (!empty($reload)) { ?>
<script>reloadConfig();</script>
<?php } ?>



<table id="cron-list" class="table table-bordered table-hover ">
    <thead>
    <tr>
        <th>ID</th>
        <th>用户</th>
        <th>时间</th>
        <th>命令</th>
        <th>状态</th>
        <th>下次执行时间</th>
        <th>上次执行时间</th>
        <th>更新时间</th>
        <th>备注</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody>
        <?php $v177454572649630206091iterated = false; ?><?php foreach ($cron_arr as $cron) { ?><?php $v177454572649630206091iterated = true; ?>
        <tr id="<?= $cron['id'] ?>">
            <td><?= $cron['id'] ?></td>
            <td><?= $cron['user'] ?></td>
            <td><code><?= $cron['time'] ?></code></td>
            <td><code><?= $cron['command'] ?></code></td>
            <td>
                <?php if ($cron['status'] == 1) { ?>
                    <span class="text-success">启用</span>
                <?php } else { ?>
                    <span class="text-danger">停用</span>
                <?php } ?>
            </td>
            <td>
                <?php if ($cron['status'] == 1) { ?>
                    <?= date('Y-m-d H:i', $cron['next_time']) ?>
                <?php } else { ?>

                <?php } ?>
            </td>
            <td>
                <?php if ($cron['last_time']) { ?>
                    <?= date('Y-m-d H:i', $cron['last_time']) ?>
                <?php } else { ?>

                <?php } ?>
            </td>
            <td>
                <?php if (time() - $cron['update_time'] < 60) { ?>
                    <span class="text-success">几秒前</span>
                <?php } else { ?>
                        <?= date('Y-m-d H:i', $cron['update_time']) ?>
                <?php } ?>
            </td>
            <td><?= $cron['description'] ?></td>
            <td>
                <a href="/cron/edit/<?= $cron['id'] ?>?server_id=<?= $server->id ?>">修改</a>
                <span class="text-muted"> | </span>
                <a href="/cron/delete/<?= $cron['id'] ?>?server_id=<?= $server->id ?>" onclick="return confirm('真的要删除吗？');" data-nopush class="delete">删除</a>
                <span class="text-muted"> | </span>
                <a href="/cron-log?server_id=<?= $server->id ?>&cron_id=<?= $cron['id'] ?>">查看日志</a>
            </td>
        </tr>
        <?php } if (!$v177454572649630206091iterated) { ?>
        <tr><td colspan="9" class="text-center">暂无数据</td></tr>
        <?php } ?>
    </tbody>
</table>

<script>
$(function() {
    var location_hash = window.location.hash;
    if (location_hash) {
        var $anchor = $(location_hash);
        if ($anchor.size() > 0) {
            $('html, body').animate({
                    scrollTop: $anchor.offset().top - 100
                }, 'fast'
            );

            var $tr = $anchor.closest('tr');
            $tr.addClass('anchor-out');
            $tr.addClass('anchor-hover');
            setTimeout(function() {
                $tr.removeClass('anchor-hover');
            }, 1000);
        }
    }
});
</script>