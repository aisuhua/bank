<?= $this->getContent() ?>
<?= $this->flashSession->output() ?>
<ol class="breadcrumb">
    <li class="active"><?= $server->serverGroup->name ?></li>
    <li class="active"><?= $server->ip ?>:<?= $server->port ?></li>
</ol>

<?php $index_class = ''; ?>
<?php $create_class = ''; ?>
<?php $ini_class = ''; ?>
<?php $cron_class = ''; ?>
<?php $cron_create_class = ''; ?>
<?php $cron_log_class = ''; ?>
<?php $command_class = ''; ?>
<?php $command_history_class = ''; ?>

<?php if ($this->dispatcher->getControllerName() == 'process-manager') { ?>
    <?php $index_class = 'active'; ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'process') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit' || $this->dispatcher->getActionName() == 'createIni' || $this->dispatcher->getActionName() == 'editIni') { ?>
        <?php $create_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'ini') { ?>
        <?php $ini_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit') { ?>
        <?php $cron_create_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron-log') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_log_class = 'active'; ?>
    <?php } ?>

<?php } elseif ($this->dispatcher->getControllerName() == 'command') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $command_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'history') { ?>
        <?php $command_history_class = 'active'; ?>
    <?php } ?>
<?php } ?>

<ul id="" class="nav nav-tabs my-tabs1" role="tablist" style="margin-bottom: 20px;">
    <li role="presentation" class="<?= $index_class ?>"><a href="/process?server_id=<?= $server->id ?>&ip=<?= $server->ip ?>&port=<?= $server->port ?>">进程列表</a></li>
    <li role="presentation" class="<?= $create_class ?>"><a href="/process/create?server_id=<?= $server->id ?>">添加/修改进程</a></li>
    <li role="presentation" class="<?= $ini_class ?>"><a href="/process/ini?server_id=<?= $server->id ?>">进程配置</a></li>
    <li role="presentation" class="<?= $cron_class ?>"><a href="/cron?server_id=<?= $server->id ?>">定时任务列表</a></li>
    <li role="presentation" class="<?= $cron_create_class ?>"><a href="/cron/create?server_id=<?= $server->id ?>">添加/修改定时任务</a></li>
    <li role="presentation" class="<?= $cron_log_class ?>"><a href="/cron-log?server_id=<?= $server->id ?>">定时任务日志</a></li>
    <li role="presentation" class="<?= $command_class ?>"><a href="/command?server_id=<?= $server->id ?>">执行命令</a></li>
    <li role="presentation" class="<?= $command_history_class ?>"><a href="/command/history?server_id=<?= $server->id ?>">命令执行历史</a></li>
    
</ul>

<script>
function reloadConfig() {
    $.get('/process-manager/reloadConfig?server_id=<?= $server->id ?>');
}

$(function() {
    var ini_editor = document.getElementById('ini');

    if (ini_editor) {
        var editor = CodeMirror.fromTextArea(document.getElementById('ini'));
        editor.setSize('100%', '100%');

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            editor.refresh();
        });
    }
});
</script>

<?php if (!empty($reload)) { ?>
<script>reloadConfig();</script>
<?php } ?>



<form method="post" action="/cron/create?server_id=<?= $server->id ?>" data-pjax>
    <?= $form->render('server_id', ['value' => $server->id]) ?>
    <div class="col-lg-6">
        <div class="form-group">
            <label for="command">命令</label>
            <?= $form->render('command') ?>
        </div>

        <div class="form-group">
            <label for="user">用户</label>
            <?= $form->render('user') ?>
        </div>
        <div class="form-group">
            <label for="status">状态</label>
            <?= $form->render('status') ?>
        </div>
        <div class="form-group">
            <label for="description">备注</label>
            <?= $form->render('description') ?>
        </div>
        <button type="submit" class="btn btn-primary">添加</button>
    </div>
    <div class="col-lg-6">
        <div class="form-group">
            <label for="times">预定义执行周期</label>
            <?= $form->render('times') ?>
        </div>
        <div class="form-group">
            <label for="time">时间</label>
            <?= $form->render('time') ?>
        </div>
        <pre>
*    *    *    *    *
-    -    -    -    -
|    |    |    |    |
|    |    |    |    |
|    |    |    |    +----- 星期 (0 - 7) (星期日 = 0 或 7)
|    |    |    +---------- 月 (1 - 12)
|    |    +--------------- 日 (1 - 31)
|    +-------------------- 小时 (0 - 23)
+------------------------- 分钟 (0 - 59)
        </pre>
        <h4>下次运行时间</h4>
        <div id="date-list" data-url="/public/getRunDates"></div>
    </div>
</form>

<script>
$(function() {
    function getRunDates() {
        var $dateList = $('#date-list');

        $.get($dateList.attr('data-url'), {time: $('#time').val()}, function (data) {
            $dateList.html(data);
        });
    }

    $('#times').change(function() {
        $('#time').val($(this).val());
        getRunDates();
    });

    var $time = $('#time');

    $time.change(function() {
        getRunDates();
    });

    if($time.length) {
        getRunDates();
    }
});
</script>