<?= $this->getContent() ?>
<?= $this->flashSession->output() ?>
<?php $group_class = ''; ?>
<?php $group_create_class = ''; ?>
<?php $server_class = ''; ?>
<?php $server_create_class = ''; ?>
<?php $process_all_class = ''; ?>
<?php $cron_all_class = ''; ?>

<?php if ($this->dispatcher->getControllerName() == 'server-group') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $group_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit') { ?>
        <?php $group_create_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'server') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $server_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit') { ?>
        <?php $server_create_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'manager') { ?>
    <?php if ($this->dispatcher->getActionName() == 'processAll') { ?>
        <?php $process_all_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'cronAll') { ?>
        <?php $cron_all_class = 'active'; ?>
    <?php } ?>
<?php } ?>

<ul id="" class="nav nav-tabs my-tabs1" role="tablist" style="margin-bottom: 20px;">
    <li role="presentation" class="<?= $group_class ?>"><a href="/server-group">分组列表</a></li>
    <li role="presentation" class="<?= $group_create_class ?>"><a href="/server-group/create">添加/修改分组</a></li>
    <li role="presentation" class="<?= $server_class ?>"><a href="/server">服务器列表</a></li>
    <li role="presentation" class="<?= $server_create_class ?>"><a href="/server/create">添加/修改服务器</a></li>
    <li role="presentation" class="<?= $process_all_class ?>"><a href="/process/all">所有进程</a></li>
    <li role="presentation" class="<?= $cron_all_class ?>"><a href="/cron/all">所有定时任务</a></li>

</ul>

<form method="post" action="/server-group/create" data-pjax>
    <div class="form-group">
        <label for="name">分组名称</label>
        <?= $form->render('name') ?>
    </div>
    <div class="form-group">
        <label for="sort">排序字段</label>
        <?= $form->render('sort') ?>
        <span id="helpBlock" class="help-block">值越大排得越靠前，有效值范围 0 ～ 999。</span>
    </div>
    <div class="form-group">
        <label for="description">备注</label>
        <?= $form->render('description') ?>
    </div>
    <button type="submit" class="btn btn-primary">添加</button>
</form>
