<?= $this->getContent() ?>
<?= $this->flashSession->output() ?>
<ol class="breadcrumb">
    <li class="active"><?= $server->serverGroup->name ?></li>
    <li class="active"><?= $server->ip ?>:<?= $server->port ?></li>
</ol>

<?php $index_class = ''; ?>
<?php $create_class = ''; ?>
<?php $ini_class = ''; ?>
<?php $cron_class = ''; ?>
<?php $cron_create_class = ''; ?>
<?php $cron_log_class = ''; ?>
<?php $command_class = ''; ?>
<?php $command_history_class = ''; ?>

<?php if ($this->dispatcher->getControllerName() == 'process-manager') { ?>
    <?php $index_class = 'active'; ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'process') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit' || $this->dispatcher->getActionName() == 'createIni' || $this->dispatcher->getActionName() == 'editIni') { ?>
        <?php $create_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'ini') { ?>
        <?php $ini_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'create' || $this->dispatcher->getActionName() == 'edit') { ?>
        <?php $cron_create_class = 'active'; ?>
    <?php } ?>
<?php } elseif ($this->dispatcher->getControllerName() == 'cron-log') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $cron_log_class = 'active'; ?>
    <?php } ?>

<?php } elseif ($this->dispatcher->getControllerName() == 'command') { ?>
    <?php if ($this->dispatcher->getActionName() == 'index') { ?>
        <?php $command_class = 'active'; ?>
    <?php } elseif ($this->dispatcher->getActionName() == 'history') { ?>
        <?php $command_history_class = 'active'; ?>
    <?php } ?>
<?php } ?>

<ul id="" class="nav nav-tabs my-tabs1" role="tablist" style="margin-bottom: 20px;">
    <li role="presentation" class="<?= $index_class ?>"><a href="/process?server_id=<?= $server->id ?>&ip=<?= $server->ip ?>&port=<?= $server->port ?>">进程列表</a></li>
    <li role="presentation" class="<?= $create_class ?>"><a href="/process/create?server_id=<?= $server->id ?>">添加/修改进程</a></li>
    <li role="presentation" class="<?= $ini_class ?>"><a href="/process/ini?server_id=<?= $server->id ?>">进程配置</a></li>
    <li role="presentation" class="<?= $cron_class ?>"><a href="/cron?server_id=<?= $server->id ?>">定时任务列表</a></li>
    <li role="presentation" class="<?= $cron_create_class ?>"><a href="/cron/create?server_id=<?= $server->id ?>">添加/修改定时任务</a></li>
    <li role="presentation" class="<?= $cron_log_class ?>"><a href="/cron-log?server_id=<?= $server->id ?>">定时任务日志</a></li>
    <li role="presentation" class="<?= $command_class ?>"><a href="/command?server_id=<?= $server->id ?>">执行命令</a></li>
    <li role="presentation" class="<?= $command_history_class ?>"><a href="/command/history?server_id=<?= $server->id ?>">命令执行历史</a></li>
    
</ul>

<script>
function reloadConfig() {
    $.get('/process-manager/reloadConfig?server_id=<?= $server->id ?>');
}

$(function() {
    var ini_editor = document.getElementById('ini');

    if (ini_editor) {
        var editor = CodeMirror.fromTextArea(document.getElementById('ini'));
        editor.setSize('100%', '100%');

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            editor.refresh();
        });
    }
});
</script>

<?php if (!empty($reload)) { ?>
<script>reloadConfig();</script>
<?php } ?>



<form method="post" action="/process/ini?server_id=<?= $server->id ?>" data-pjax>
    <div class="form-group">
        <textarea id="ini" name="ini" style="height: auto;" class="form-control"><?= $ini ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">保存</button>
</form>

<script>
$(function() {
    autosize(document.querySelector('textarea'));
});
</script>