<?php
$db_ms = '172.17.0.2';
$db_user = 'root';
$db_pass = 'suhua123';
$db_name = 'bank';
$charset = 'utf8mb4';

$dbh = new PDO("mysql:host={$db_ms};dbname={$db_name}", $db_user, $db_pass);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$dbh->exec("set names {$charset}");

$sql = "INSERT INTO `trans` (`acc_number` ,`trans_time`, `amount`, `opp_acc_number`, `opp_customer_name`, `update_time`, `create_time`) 
                VALUES (:acc_number, :trans_time, :amount, :opp_acc_number, :opp_customer_name, :update_time, :create_time)";
$stmt = $dbh->prepare($sql);

$row = 1;
$now = time();
if (($handle = fopen("trans.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        if ($row++ == 1)
        {
            continue;
        }

        $stmt->execute(array(
            'acc_number' =>  $data[0],
            'trans_time'=>$data[1],
            'amount'=>$data[2],
            'opp_acc_number'=>$data[3],
            'opp_customer_name'=>$data[4],
            'create_time'=>$now,
            'update_time'=>$now
        ));
    }
    fclose($handle);
}