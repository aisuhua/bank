<?php
$db_ms = '172.17.0.2';
$db_user = 'root';
$db_pass = 'suhua123';
$db_name = 'bank';
$charset = 'utf8mb4';

$dbh = new PDO("mysql:host={$db_ms};dbname={$db_name}", $db_user, $db_pass);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$dbh->exec("set names {$charset}");

$sql = "INSERT INTO `account` (`customer_code` ,`acc_number`, `open_org`, `balance`, `update_time`, `create_time`) 
                VALUES (:customer_code, :acc_number, :open_org, :balance, :update_time, :create_time)";
$stmt = $dbh->prepare($sql);

$row = 1;
$now = time();
if (($handle = fopen("acc.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        if ($row++ == 1)
        {
            continue;
        }

        $stmt->execute(array(
            'customer_code' =>  $data[0],
            'acc_number'=>$data[1],
            'open_org'=>$data[2],
            'balance'=>$data[3],
            'create_time'=>$now,
            'update_time'=>$now
        ));
    }
    fclose($handle);
}